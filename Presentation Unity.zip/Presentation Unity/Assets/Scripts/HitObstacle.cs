using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HitObstacle : MonoBehaviour
{
    private CharacterController controller;
    [SerializeField] private GameObject spawnPoint;
    [SerializeField] private Stopwatch stopwatch;
     
    // Start is called before the first frame update
    void Start()
    {
        controller = gameObject.GetComponent<CharacterController>();
    }

    // Update is called once per frame
    void Update()
    {
        
    }
    private void OnControllerColliderHit(ControllerColliderHit hit)
    {
        if (hit.gameObject.tag.Equals("Obstacle"))
        {
            Debug.Log("hit");
            controller.enabled = false;
            controller.transform.position = spawnPoint.transform.position;
            controller.enabled = true;
            stopwatch.Restart();
        }
    }


}
