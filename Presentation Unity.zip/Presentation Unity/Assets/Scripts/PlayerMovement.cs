using System.Collections;

using System.Collections.Generic;

using UnityEngine;



public class PlayerMovement : MonoBehaviour
{
    private CharacterController controller;
    private Vector3 playerVelocity;
    private bool groundedPlayer;
    private bool canMove;
    [SerializeField] private float horizontalSpeed = 2.0f;
    [SerializeField] private float jumpHeight = 1.0f;
    [SerializeField] private float gravityValue = -9.81f;
    [SerializeField] private float forwardSpeed = 3;

    private void Start()
    {
        controller = gameObject.GetComponent<CharacterController>();
        canMove = true;
    }

    void Update()
    {
        //Quand le joueur touche un obstacle ou finit le jeu, on l'emp�che de bouger
        if (!canMove)
            return;


        groundedPlayer = controller.isGrounded;
        if (groundedPlayer && playerVelocity.y < 0)
        {
            playerVelocity.y = -2f;
        }

        // Input.GetAxis("Horizontal")
        //      -> Si "Q" est press�, Input.GetAxis("Horizontal") = -1
        //      -> Si "D" est press�, Input.GetAxis("Horizontal") = 1
        // Cela va nous permettre de bouger � gauche ou � droite
        Vector3 move = new Vector3(Input.GetAxis("Horizontal") * horizontalSpeed, 0, forwardSpeed);
        controller.Move(Time.deltaTime * move);

        if (move != Vector3.zero)
        {
            gameObject.transform.forward = move;
        }

        // Si notre character est au sol et que la barre espace est press�e ..
        if (Input.GetButtonDown("Jump") && groundedPlayer)
        {
            Debug.Log("Jump");
            // Calcul de la vitesse du saut 
            playerVelocity.y += Mathf.Sqrt(jumpHeight * -3.0f * gravityValue);
        }

        playerVelocity.y += gravityValue * Time.deltaTime;
        // On applique le "saut" � notre controller
        controller.Move(playerVelocity * Time.deltaTime);
    }

    public void StopMovement()
    {
        canMove = false;
    }

}