using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class triggeredBloc : MonoBehaviour
{
    private float speed = 0f;
    private Vector3 originalPosition = new Vector3();
    private Vector3 maxNewPosition = new Vector3();
    [SerializeField] private Vector3 directionMovement;
    [SerializeField] private float maxDistance;
    public void Start()
    {
        originalPosition = GetComponent<Transform>().position;
        maxNewPosition = GetComponent<Transform>().position;
    }

    public void Update()
    {
        if (haveToMove())
        {
            GetComponent<Transform>().Translate(directionMovement * speed * Time.deltaTime);
        }
    }

    private bool haveToMove()
    {
        if(directionMovement.x != 0)
        {
            if(directionMovement.x < 0)
            {
                return GetComponent<Transform>().position.x > maxNewPosition.x;
            }
            else
            {
                return GetComponent<Transform>().position.x < maxNewPosition.x;

            }
        }
        if (directionMovement.y != 0)
        {
            if (directionMovement.y < 0)
            {
                return GetComponent<Transform>().position.y > maxNewPosition.y;
            }
            else
            {
                return GetComponent<Transform>().position.y < maxNewPosition.y;

            }
        }
        return false;


    }
    public void triggered()
    {
        Debug.Log("triggered" + Time.deltaTime);
        speed = 4f;
        maxNewPosition = originalPosition + directionMovement * maxDistance;
    }

}
