using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Stopwatch : MonoBehaviour
{
    bool active;
    float currentTime;
    public Text currentTimeText;

    // Start is called before the first frame update
    void Start()
    {
        active = true;
        currentTime = 0;
    }

    // Update is called once per frame
    void Update()
    {
        if (active)
        {
            currentTime += Time.deltaTime;
        }
        currentTimeText.text = ((int) currentTime).ToString();
    }

    public void Restart()
    {
        currentTime = 0;
    }

    public void Stop()
    {
        active = false;
    }
}