using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class Finish : MonoBehaviour
{
    public Text restartText;
    private bool finished;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKeyDown(KeyCode.Return) && finished)
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().name);
        }
       
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag.Equals("Player"))
        {
            Debug.Log("Stop");
            /*UnityEditor.EditorApplication.isPlaying = false;*/
            GameObject.FindObjectOfType<Stopwatch>().Stop();
            GameObject.FindObjectOfType<PlayerMovement>().StopMovement();
            restartText.enabled = true;
            finished = true;
        }
    }
}
